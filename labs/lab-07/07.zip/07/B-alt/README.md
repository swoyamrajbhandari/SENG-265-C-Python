# Goal for this exercise:

Modify list.c and list.h so that linked-list nodes now hold
a char field and an int field. (That is, the linked-list node
definition current holds a single char array field.)

The names of the fields are suggested by the print_node function
in exprtester.c

Note that the exercise has been designed so that *only* the code
in list.c and list.h must be modified.
